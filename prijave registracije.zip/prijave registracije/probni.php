<html>
<head>
<?php
if (isset($_GET["msg"]) && $_GET["msg"] == 'failedpopuni') {
echo "<script type = 'text/javascript'>alert('Popuni sva polja');</script>";
}
if (isset($_GET["msg"]) && $_GET["msg"] == 'failedlozinka') {
echo "<script type = 'text/javascript'>alert('Unio si krivu lozinku');</script>";
}
if (isset($_GET["msg"]) && $_GET["msg"] == 'failedkorime') {
echo "<script type = 'text/javascript'>alert('Korisničko ime je zauzeto');</script>";
}
if (isset($_GET["msg"]) && $_GET["msg"] == 'failedkorisnicko') {
echo "<script type = 'text/javascript'>alert('Unio si krivo korisnicko ime');</script>";
}
if (isset($_GET["msg"]) && $_GET["msg"] == 'failedponloz') {
echo "<script type = 'text/javascript'>alert('Lozinke ti se ne podudaraju');</script>";
}

?>
<style type = "text/css">
div{
  width: 500px;
  margin: auto;
  border: 3px solid black;
  background-color: pink;
  text-align:center;
}
<?php
	$upozorenjeime = "";
	$upozorenjelozinka = "";
	$upozorenjeregistracija = "";
?>
</style>

</head>
<body>

<div><h1>Prijavi se</h1>
<form action = "prijava.php" method = "post">
<br>
Korisničko ime:<br>
<input type = "text" name = "korisnickoime">
<br><br>
Lozinka:<br>
<input type = "password" name = "lozinka"><br><br>
<input type = "submit" name = "submit" value = "Prijavi se"><br><br>


</form></div>
<br><br><br>
<div><h1>Registriraj se</h1>
<form action = "registracija.php" method = "post">
<br><br>
Korisničko ime:<br>
<input type = "text" name = "korisnickoime">
<br><br>
Lozinka:<br>
<input type = "password" name = "lozinka"><br><br>
Ponovi lozinku:<br>
<input type = "password" name = "lozinkapon"><br><br>
Mjesto stanovanja:<br>
<input type = "text" name = "mjestostanovanja"><br><br>
<input type = "submit" name = "submit" value = "Registriraj se"/><br><br>


<br>
</form></div>




<a href = "admini.php">Prijava za admine</a>


</body>
</html>