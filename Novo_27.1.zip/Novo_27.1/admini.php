<html>
<head>
<?php
if (isset($_GET["msg"]) && $_GET["msg"] == 'failedpopuni') {
echo "<script type = 'text/javascript'>alert('Popuni sva polja');</script>";
}
if (isset($_GET["msg"]) && $_GET["msg"] == 'failedlozinka') {
echo "<script type = 'text/javascript'>alert('Unio si krivu lozinku');</script>";
}
if (isset($_GET["msg"]) && $_GET["msg"] == 'failedkorime') {
echo "<script type = 'text/javascript'>alert('Korisničko ime je zauzeto');</script>";
}
if (isset($_GET["msg"]) && $_GET["msg"] == 'failedkorisnicko') {
echo "<script type = 'text/javascript'>alert('Unio si krivo korisnicko ime');</script>";
}

?>
<style type = "text/css">
div{
  width: 500px;
  margin: auto;
  border: 3px solid black;
  background-color: pink;
  text-align:center;
}

</style>

</head>
<body>

<div><h1>Prijavi se</h1>
<form action = "prijavaadmin.php" method = "post">
<br>
Korisničko ime:<br>
<input type = "text" name = "korisnickoime">
<br><br>
Lozinka:<br>
<input type = "password" name = "lozinka"><br><br>
<input type = "submit" name = "submit" value = "Prijavi se"><br><br>


</form></div>
<br><br><br>








</body>
</html>